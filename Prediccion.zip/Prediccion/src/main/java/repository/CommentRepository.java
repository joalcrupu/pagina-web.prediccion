package com.jdc.Prediccion.repository;

import com.jdc.Prediccion.entity.Comment;
import com.jdc.Prediccion.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface CommentRepository extends JpaRepository<Comment, Long> {

    List<Comment> findByGameNameOrderByCreatedAtDesc(String gameName);

    List<Comment> findByUser_IdOrderByCreatedAtDesc(Long userId);

    // METODO FALTANTE - Buscar comentario por usuario y nombre del juego
    Optional<Comment> findByUserAndGameName(User user, String gameName);

    @Query("SELECT AVG(c.rating) FROM Comment c WHERE c.gameName = :gameName AND c.rating IS NOT NULL")
    Double getAverageRatingByGameName(@Param("gameName") String gameName);
}