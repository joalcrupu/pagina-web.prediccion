package com.jdc.Prediccion.repository;

import com.jdc.Prediccion.entity.Game;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface GameRepository extends JpaRepository<Game, Long> {

    @Query("SELECT g FROM Game g WHERE LOWER(g.nombre) LIKE LOWER(CONCAT('%', :nombre, '%'))")
    List<Game> findByNombreContaining(@Param("nombre") String nombre);

    List<Game> findByGenero(String genero);

    List<Game> findByEditorial(String editorial);

    List<Game> findByPlataforma(String plataforma);
}