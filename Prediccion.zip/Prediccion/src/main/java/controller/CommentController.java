package com.jdc.Prediccion.controller;

import com.jdc.Prediccion.entity.Comment;
import com.jdc.Prediccion.entity.User;
import com.jdc.Prediccion.repository.CommentRepository;
import com.jdc.Prediccion.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("/api/comments")
public class CommentController {

    @Autowired
    private CommentRepository commentRepository;

    @Autowired
    private UserRepository userRepository;

    @PostMapping("/add")
    public ResponseEntity<Map<String, Object>> addComment(@RequestBody Map<String, String> request) {
        Map<String, Object> response = new HashMap<>();

        try {
            Authentication auth = SecurityContextHolder.getContext().getAuthentication();
            String username = auth.getName();
            System.out.println("=== AGREGAR COMENTARIO ===");
            System.out.println("Usuario: " + username);

            User user = userRepository.findByUsername(username);
            if (user == null) {
                System.out.println("ERROR: Usuario no encontrado");
                response.put("error", "Usuario no encontrado");
                return ResponseEntity.badRequest().body(response);
            }

            String gameName = request.get("gameName");
            String content = request.get("content");
            String ratingStr = request.get("rating");

            System.out.println("Juego: " + gameName);
            System.out.println("Comentario: " + content);
            System.out.println("Calificacion: " + ratingStr);

            if (gameName == null || content == null || content.trim().isEmpty()) {
                System.out.println("ERROR: Comentario vacio");
                response.put("error", "El comentario no puede estar vacio");
                return ResponseEntity.badRequest().body(response);
            }

            // Verificar si ya existe un comentario de este usuario para este juego usando Optional
            Optional<Comment> existingCommentOpt = commentRepository.findByUserAndGameName(user, gameName);
            Comment comment;
            boolean isUpdate = false;

            if (existingCommentOpt.isPresent()) {
                Comment existingComment = existingCommentOpt.get();
                System.out.println("Actualizando comentario existente ID: " + existingComment.getId());
                existingComment.setContent(content);
                if (ratingStr != null && !ratingStr.isEmpty()) {
                    existingComment.setRating(Double.parseDouble(ratingStr));
                }
                comment = commentRepository.save(existingComment);
                isUpdate = true;
                response.put("message", "Comentario actualizado correctamente");
            } else {
                System.out.println("Creando nuevo comentario");
                comment = new Comment(user, content, gameName);
                if (ratingStr != null && !ratingStr.isEmpty()) {
                    comment.setRating(Double.parseDouble(ratingStr));
                }
                comment = commentRepository.save(comment);
                response.put("message", "Comentario agregado correctamente");
            }

            System.out.println("Comentario guardado con ID: " + comment.getId());
            System.out.println("==============================");

            response.put("success", true);
            response.put("isUpdate", isUpdate);
            response.put("comment", Map.of(
                    "id", comment.getId(),
                    "username", user.getUsername(),
                    "content", comment.getContent(),
                    "rating", comment.getRating() != null ? comment.getRating() : 0.0,
                    "createdAt", comment.getCreatedAt().toString(),
                    "userId", user.getId()
            ));

            return ResponseEntity.ok(response);

        } catch (Exception e) {
            System.err.println("ERROR: " + e.getMessage());
            e.printStackTrace();
            response.put("error", "Error al guardar comentario: " + e.getMessage());
            return ResponseEntity.internalServerError().body(response);
        }
    }

    @GetMapping("/game/{gameName}")
    public ResponseEntity<Map<String, Object>> getCommentsByGame(@PathVariable String gameName) {
        Map<String, Object> response = new HashMap<>();

        try {
            System.out.println("=== OBTENER COMENTARIOS ===");
            System.out.println("Buscando comentarios para: " + gameName);

            List<Comment> comments = commentRepository.findByGameNameOrderByCreatedAtDesc(gameName);

            System.out.println("Comentarios encontrados: " + comments.size());

            Double avgRating = commentRepository.getAverageRatingByGameName(gameName);
            System.out.println("Calificacion promedio: " + avgRating);

            List<Map<String, Object>> commentList = comments.stream().map(comment -> {
                Map<String, Object> c = new HashMap<>();
                c.put("id", comment.getId());
                c.put("username", comment.getUsername());
                c.put("content", comment.getContent());
                c.put("rating", comment.getRating() != null ? comment.getRating() : 0.0);
                c.put("createdAt", comment.getCreatedAt().toString());
                c.put("userId", comment.getUser().getId());
                System.out.println("  - Comentario ID: " + comment.getId() + ", Usuario: " + comment.getUsername() + ", Rating: " + comment.getRating());
                return c;
            }).collect(java.util.stream.Collectors.toList());

            response.put("success", true);
            response.put("comments", commentList);
            response.put("averageRating", avgRating != null ? avgRating : 0.0);
            response.put("total", commentList.size());

            System.out.println("==========================");

            return ResponseEntity.ok(response);

        } catch (Exception e) {
            System.err.println("ERROR: " + e.getMessage());
            e.printStackTrace();
            response.put("error", "Error al obtener comentarios: " + e.getMessage());
            return ResponseEntity.internalServerError().body(response);
        }
    }

    @GetMapping("/user/{gameName}")
    public ResponseEntity<Map<String, Object>> getUserComment(@PathVariable String gameName) {
        Map<String, Object> response = new HashMap<>();

        try {
            Authentication auth = SecurityContextHolder.getContext().getAuthentication();
            String username = auth.getName();
            System.out.println("=== VERIFICAR COMENTARIO USUARIO ===");
            System.out.println("Usuario: " + username);
            System.out.println("Juego: " + gameName);

            User user = userRepository.findByUsername(username);

            if (user == null) {
                System.out.println("ERROR: Usuario no encontrado");
                response.put("error", "Usuario no encontrado");
                return ResponseEntity.badRequest().body(response);
            }

            Optional<Comment> commentOpt = commentRepository.findByUserAndGameName(user, gameName);

            if (commentOpt.isPresent()) {
                Comment comment = commentOpt.get();
                System.out.println("Comentario encontrado - ID: " + comment.getId() + ", Rating: " + comment.getRating());
                response.put("hasComment", true);
                response.put("comment", Map.of(
                        "id", comment.getId(),
                        "content", comment.getContent(),
                        "rating", comment.getRating() != null ? comment.getRating() : 0.0
                ));
            } else {
                System.out.println("No hay comentario de este usuario para este juego");
                response.put("hasComment", false);
            }
            response.put("success", true);

            System.out.println("================================");

            return ResponseEntity.ok(response);

        } catch (Exception e) {
            System.err.println("ERROR: " + e.getMessage());
            e.printStackTrace();
            response.put("error", "Error al obtener comentario del usuario: " + e.getMessage());
            return ResponseEntity.internalServerError().body(response);
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Map<String, Object>> deleteComment(@PathVariable Long id) {
        Map<String, Object> response = new HashMap<>();

        try {
            Authentication auth = SecurityContextHolder.getContext().getAuthentication();
            String username = auth.getName();
            User currentUser = userRepository.findByUsername(username);
            System.out.println("=== ELIMINAR COMENTARIO ===");
            System.out.println("Usuario: " + username);
            System.out.println("Comentario ID: " + id);

            if (currentUser == null) {
                System.out.println("ERROR: Usuario no encontrado");
                response.put("error", "Usuario no encontrado");
                return ResponseEntity.badRequest().body(response);
            }

            Comment comment = commentRepository.findById(id).orElse(null);
            if (comment == null) {
                System.out.println("ERROR: Comentario no encontrado");
                response.put("error", "Comentario no encontrado");
                return ResponseEntity.badRequest().body(response);
            }

            boolean isAdmin = "ADMIN".equals(currentUser.getRole());
            boolean isOwner = comment.getUser().getId().equals(currentUser.getId());

            if (!isAdmin && !isOwner) {
                System.out.println("ERROR: Sin permisos - isAdmin: " + isAdmin + ", isOwner: " + isOwner);
                response.put("error", "No tienes permiso para eliminar este comentario");
                return ResponseEntity.status(403).body(response);
            }

            commentRepository.deleteById(id);
            System.out.println("Comentario eliminado correctamente");
            System.out.println("==============================");
            response.put("success", true);
            response.put("message", "Comentario eliminado correctamente");

            return ResponseEntity.ok(response);

        } catch (Exception e) {
            System.err.println("ERROR: " + e.getMessage());
            e.printStackTrace();
            response.put("error", "Error al eliminar comentario: " + e.getMessage());
            return ResponseEntity.internalServerError().body(response);
        }
    }

    @PostMapping("/add-prediccion")
    public ResponseEntity<Map<String, Object>> addComentarioPrediccion(@RequestBody Map<String, String> request) {
        Map<String, Object> response = new HashMap<>();

        try {
            Authentication auth = SecurityContextHolder.getContext().getAuthentication();
            String username = auth.getName();

            User user = userRepository.findByUsername(username);
            if (user == null) {
                response.put("error", "Usuario no encontrado");
                return ResponseEntity.badRequest().body(response);
            }

            String gameName = request.get("gameName");
            String content = request.get("content");

            if (gameName == null || content == null || content.trim().isEmpty()) {
                response.put("error", "El comentario no puede estar vacio");
                return ResponseEntity.badRequest().body(response);
            }

            Comment comment = new Comment(user, content, gameName);
            comment = commentRepository.save(comment);

            response.put("success", true);
            response.put("message", "Comentario agregado correctamente");
            response.put("comment", Map.of(
                    "id", comment.getId(),
                    "username", user.getUsername(),
                    "content", comment.getContent(),
                    "createdAt", comment.getCreatedAt().toString(),
                    "userId", user.getId()
            ));

            return ResponseEntity.ok(response);

        } catch (Exception e) {
            response.put("error", "Error al guardar comentario: " + e.getMessage());
            return ResponseEntity.internalServerError().body(response);
        }
    }

    @PutMapping("/{id}")
    public ResponseEntity<Map<String, Object>> editComment(@PathVariable Long id, @RequestBody Map<String, String> request) {
        Map<String, Object> response = new HashMap<>();

        try {
            Authentication auth = SecurityContextHolder.getContext().getAuthentication();
            String username = auth.getName();
            User currentUser = userRepository.findByUsername(username);
            System.out.println("=== EDITAR COMENTARIO ===");
            System.out.println("Usuario: " + username);
            System.out.println("Comentario ID: " + id);

            if (currentUser == null) {
                System.out.println("ERROR: Usuario no encontrado");
                response.put("error", "Usuario no encontrado");
                return ResponseEntity.badRequest().body(response);
            }

            Comment comment = commentRepository.findById(id).orElse(null);
            if (comment == null) {
                System.out.println("ERROR: Comentario no encontrado");
                response.put("error", "Comentario no encontrado");
                return ResponseEntity.badRequest().body(response);
            }

            if (!comment.getUser().getId().equals(currentUser.getId())) {
                System.out.println("ERROR: Sin permisos - No es el dueño");
                response.put("error", "No tienes permiso para editar este comentario");
                return ResponseEntity.status(403).body(response);
            }

            String newContent = request.get("content");
            if (newContent == null || newContent.trim().isEmpty()) {
                System.out.println("ERROR: Contenido vacio");
                response.put("error", "El comentario no puede estar vacio");
                return ResponseEntity.badRequest().body(response);
            }

            String ratingStr = request.get("rating");
            if (ratingStr != null && !ratingStr.isEmpty()) {
                comment.setRating(Double.parseDouble(ratingStr));
                System.out.println("Nueva calificacion: " + ratingStr);
            }

            comment.setContent(newContent);
            commentRepository.save(comment);
            System.out.println("Comentario actualizado correctamente");
            System.out.println("==============================");

            response.put("success", true);
            response.put("message", "Comentario editado correctamente");

            return ResponseEntity.ok(response);

        } catch (Exception e) {
            System.err.println("ERROR: " + e.getMessage());
            e.printStackTrace();
            response.put("error", "Error al editar comentario: " + e.getMessage());
            return ResponseEntity.internalServerError().body(response);
        }
    }
}