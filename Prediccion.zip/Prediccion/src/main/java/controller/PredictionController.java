package com.jdc.Prediccion.controller;

import com.jdc.Prediccion.entity.Comment;
import com.jdc.Prediccion.entity.User;
import com.jdc.Prediccion.repository.UserRepository;
import com.jdc.Prediccion.service.CommentService;
import com.jdc.Prediccion.service.FileService;
import com.jdc.Prediccion.service.PredictionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/prediccion")
@CrossOrigin(origins = "*")
public class PredictionController {

    @Autowired
    private PredictionService predictionService;

    @Autowired
    private FileService fileService;

    @Autowired
    private CommentService commentService;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @PostMapping("/upload")
    public ResponseEntity<Map<String, String>> uploadFiles(
            @RequestParam("files") MultipartFile[] files
    ) {

        Map<String, String> response = new HashMap<>();

        try {

            if (files == null || files.length == 0) {
                response.put("error", "No se recibieron archivos");
                return ResponseEntity.badRequest().body(response);
            }

            fileService.processFiles(files);

            response.put("mensaje", "Archivos procesados correctamente");

            return ResponseEntity.ok(response);

        } catch (Exception e) {

            response.put("error", e.getMessage());

            return ResponseEntity.internalServerError().body(response);
        }
    }

    @GetMapping("/buscar")
    public ResponseEntity<Map<String, Object>> buscarJuego(
            @RequestParam String nombre
    ) {

        try {

            Map<String, Object> resultado = predictionService.buscarJuego(nombre);

            List<Comment> comments =
                    commentService.getCommentsByGame(nombre);

            resultado.put("comments", comments);
            resultado.put("totalComments", comments.size());

            return ResponseEntity.ok(resultado);

        } catch (Exception e) {

            Map<String, Object> error = new HashMap<>();

            error.put("encontrado", false);
            error.put("error", e.getMessage());

            return ResponseEntity.badRequest().body(error);
        }
    }

    @PostMapping("/predecir")
    public ResponseEntity<Map<String, Object>> predecirJuego(
            @RequestBody Map<String, Object> request
    ) {

        try {

            String nombre =
                    (String) request.get("nombre");

            String genero =
                    (String) request.getOrDefault("genero", "");

            String plataforma =
                    (String) request.getOrDefault("plataforma", "");

            String editorial =
                    (String) request.getOrDefault("editorial", "");

            Integer anio =
                    (Integer) request.getOrDefault("anio", 2024);

            String rating =
                    (String) request.getOrDefault("rating", "E");

            Map<String, Object> resultado =
                    predictionService.predecirJuego(
                            nombre,
                            genero,
                            plataforma,
                            editorial,
                            anio,
                            rating
                    );

            return ResponseEntity.ok(resultado);

        } catch (Exception e) {

            Map<String, Object> error = new HashMap<>();

            error.put("error", e.getMessage());

            return ResponseEntity.badRequest().body(error);
        }
    }

    @GetMapping("/comentarios")
    public ResponseEntity<Map<String, Object>> getComentarios(
            @RequestParam String gameName
    ) {

        Map<String, Object> response = new HashMap<>();

        try {

            List<Comment> comments =
                    commentService.getCommentsByGame(gameName);

            response.put("success", true);
            response.put("comments", comments);
            response.put("total", comments.size());

            return ResponseEntity.ok(response);

        } catch (Exception e) {

            response.put("success", false);
            response.put("error", e.getMessage());

            return ResponseEntity.badRequest().body(response);
        }
    }

    @GetMapping("/usuario-actual")
    public ResponseEntity<Map<String, Object>> getUsuarioActual(
            Authentication authentication
    ) {

        Map<String, Object> response = new HashMap<>();

        if (authentication != null &&
                authentication.isAuthenticated() &&
                !authentication.getName().equals("anonymousUser")) {

            String username = authentication.getName();
            User user = userRepository.findByUsername(username);

            if (user != null) {
                response.put("authenticated", true);
                response.put("username", user.getUsername());
                response.put("id", user.getId());
                response.put("role", user.getRole());
            } else {
                response.put("authenticated", false);
            }

        } else {

            response.put("authenticated", false);
        }

        return ResponseEntity.ok(response);
    }

    @PostMapping("/registro")
    public ResponseEntity<Map<String, String>> registrarUsuario(@RequestBody Map<String, String> request) {
        try {
            String username = request.get("username");
            String password = request.get("password");
            String role = request.getOrDefault("role", "USER");

            if (username == null || username.trim().isEmpty()) {
                Map<String, String> error = new HashMap<>();
                error.put("error", "El nombre de usuario es requerido");
                return ResponseEntity.badRequest().body(error);
            }

            if (password == null || password.trim().isEmpty()) {
                Map<String, String> error = new HashMap<>();
                error.put("error", "La contrasena es requerida");
                return ResponseEntity.badRequest().body(error);
            }

            if (userRepository.findByUsername(username) != null) {
                Map<String, String> error = new HashMap<>();
                error.put("error", "El usuario ya existe");
                return ResponseEntity.badRequest().body(error);
            }

            User newUser = new User();
            newUser.setUsername(username);
            newUser.setPassword(passwordEncoder.encode(password));
            newUser.setRole(role.toUpperCase());

            userRepository.save(newUser);

            Map<String, String> response = new HashMap<>();
            response.put("mensaje", "Usuario creado exitosamente");
            response.put("username", username);
            response.put("role", role);
            return ResponseEntity.ok(response);

        } catch (Exception e) {
            Map<String, String> error = new HashMap<>();
            error.put("error", "Error al crear usuario: " + e.getMessage());
            return ResponseEntity.internalServerError().body(error);
        }
    }

    @PostMapping("/comentario")
    public ResponseEntity<Map<String, Object>> saveComentario(
            @RequestBody Map<String, String> request,
            Authentication authentication
    ) {

        Map<String, Object> response = new HashMap<>();

        try {

            if (authentication == null ||
                    !authentication.isAuthenticated()) {

                response.put("success", false);
                response.put("error",
                        "Debes iniciar sesion");

                return ResponseEntity.status(401).body(response);
            }

            String gameName = request.get("gameName");
            String content = request.get("content");

            if (gameName == null || gameName.trim().isEmpty()) {

                response.put("success", false);
                response.put("error",
                        "Nombre del juego requerido");

                return ResponseEntity.badRequest().body(response);
            }

            if (content == null || content.trim().isEmpty()) {

                response.put("success", false);
                response.put("error",
                        "Comentario vacio");

                return ResponseEntity.badRequest().body(response);
            }

            String username = authentication.getName();

            User user =
                    userRepository.findByUsername(username);

            if (user == null) {

                response.put("success", false);
                response.put("error",
                        "Usuario no encontrado");

                return ResponseEntity.badRequest().body(response);
            }

            Comment comment =
                    new Comment(user,
                            content.trim(),
                            gameName.trim());

            Comment saved =
                    commentService.saveComment(comment);

            response.put("success", true);
            response.put("comment", saved);

            return ResponseEntity.ok(response);

        } catch (Exception e) {

            response.put("success", false);
            response.put("error", e.getMessage());

            return ResponseEntity.badRequest().body(response);
        }
    }

    @PutMapping("/comentario/{id}")
    public ResponseEntity<Map<String, Object>> editarComentario(
            @PathVariable Long id,
            @RequestBody Map<String, String> request,
            Authentication authentication
    ) {

        Map<String, Object> response = new HashMap<>();

        try {

            if (authentication == null ||
                    !authentication.isAuthenticated()) {

                response.put("success", false);
                response.put("error",
                        "No autorizado");

                return ResponseEntity.status(401).body(response);
            }

            Comment comment =
                    commentService.getCommentById(id);

            if (comment == null) {

                response.put("success", false);
                response.put("error",
                        "Comentario no encontrado");

                return ResponseEntity.badRequest().body(response);
            }

            String username = authentication.getName();

            User user =
                    userRepository.findByUsername(username);

            if (user == null) {

                response.put("success", false);
                response.put("error",
                        "Usuario no encontrado");

                return ResponseEntity.badRequest().body(response);
            }

            boolean isAdmin =
                    user.getRole().equalsIgnoreCase("ADMIN");

            boolean isOwner =
                    comment.getUser()
                            .getUsername()
                            .equals(username);

            if (!isAdmin && !isOwner) {

                response.put("success", false);
                response.put("error",
                        "No tienes permisos");

                return ResponseEntity.status(403).body(response);
            }

            comment.setContent(
                    request.get("content").trim()
            );

            Comment updated =
                    commentService.saveComment(comment);

            response.put("success", true);
            response.put("comment", updated);

            return ResponseEntity.ok(response);

        } catch (Exception e) {

            response.put("success", false);
            response.put("error", e.getMessage());

            return ResponseEntity.badRequest().body(response);
        }
    }

    @DeleteMapping("/comentario/{id}")
    public ResponseEntity<Map<String, Object>> deleteComentario(
            @PathVariable Long id,
            Authentication authentication
    ) {

        Map<String, Object> response = new HashMap<>();

        try {

            if (authentication == null ||
                    !authentication.isAuthenticated()) {

                response.put("success", false);
                response.put("error",
                        "No autorizado");

                return ResponseEntity.status(401).body(response);
            }

            Comment comment =
                    commentService.getCommentById(id);

            if (comment == null) {

                response.put("success", false);
                response.put("error",
                        "Comentario no encontrado");

                return ResponseEntity.badRequest().body(response);
            }

            String username = authentication.getName();

            User user =
                    userRepository.findByUsername(username);

            boolean isAdmin =
                    user.getRole().equalsIgnoreCase("ADMIN");

            boolean isOwner =
                    comment.getUser()
                            .getUsername()
                            .equals(username);

            if (!isAdmin && !isOwner) {

                response.put("success", false);
                response.put("error",
                        "No tienes permisos");

                return ResponseEntity.status(403).body(response);
            }

            commentService.deleteComment(id);

            response.put("success", true);
            response.put("message",
                    "Comentario eliminado");

            return ResponseEntity.ok(response);

        } catch (Exception e) {

            response.put("success", false);
            response.put("error", e.getMessage());

            return ResponseEntity.badRequest().body(response);
        }
    }

    @GetMapping("/ping")
    public ResponseEntity<String> ping() {
        return ResponseEntity.ok("pong");
    }
}