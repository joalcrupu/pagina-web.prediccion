package controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class HomeController {


    @GetMapping("/admin")
    public String admin() {
        return "admin";
    }

    @GetMapping("/usuario")
    public String usuario() {
        return "usuario";
    }
}