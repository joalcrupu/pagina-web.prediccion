package com.jdc.Prediccion.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "games")
public class Game {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String nombre;
    private String plataforma;
    private Integer anio;
    private String genero;
    private String editorial;

    private Double ventasNA;
    private Double ventasEU;
    private Double ventasJP;
    private Double ventasOtros;
    private Double ventasGlobal;

    private Double criticScore;
    private Double userScore;

    private String rating;

    // Getters y Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public String getPlataforma() { return plataforma; }
    public void setPlataforma(String plataforma) { this.plataforma = plataforma; }

    public Integer getAnio() { return anio; }
    public void setAnio(Integer anio) { this.anio = anio; }

    public String getGenero() { return genero; }
    public void setGenero(String genero) { this.genero = genero; }

    public String getEditorial() { return editorial; }
    public void setEditorial(String editorial) { this.editorial = editorial; }

    public Double getVentasNA() { return ventasNA; }
    public void setVentasNA(Double ventasNA) { this.ventasNA = ventasNA; }

    public Double getVentasEU() { return ventasEU; }
    public void setVentasEU(Double ventasEU) { this.ventasEU = ventasEU; }

    public Double getVentasJP() { return ventasJP; }
    public void setVentasJP(Double ventasJP) { this.ventasJP = ventasJP; }

    public Double getVentasOtros() { return ventasOtros; }
    public void setVentasOtros(Double ventasOtros) { this.ventasOtros = ventasOtros; }

    public Double getVentasGlobal() { return ventasGlobal; }
    public void setVentasGlobal(Double ventasGlobal) { this.ventasGlobal = ventasGlobal; }

    public Double getCriticScore() { return criticScore; }
    public void setCriticScore(Double criticScore) { this.criticScore = criticScore; }

    public Double getUserScore() { return userScore; }
    public void setUserScore(Double userScore) { this.userScore = userScore; }

    public String getRating() { return rating; }
    public void setRating(String rating) { this.rating = rating; }
}