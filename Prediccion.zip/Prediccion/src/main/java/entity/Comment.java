package com.jdc.Prediccion.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "comments")
public class Comment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "usuario_id", nullable = false)
    private com.jdc.Prediccion.entity.User user;

    @Column(nullable = false, length = 1000)
    private String content;

    @Column(name = "game_name", nullable = false, length = 255)
    private String gameName;

    @Column(name = "created_at")
    private LocalDateTime createdAt;

    @Column(nullable = true)
    private Double rating;

    public Comment() {
        this.createdAt = LocalDateTime.now();
    }

    public Comment(com.jdc.Prediccion.entity.User user, String content, String gameName) {
        this.user = user;
        this.content = content;
        this.gameName = gameName;
        this.createdAt = LocalDateTime.now();
    }

    public Comment(com.jdc.Prediccion.entity.User user, String content, String gameName, Double rating) {
        this.user = user;
        this.content = content;
        this.gameName = gameName;
        this.rating = rating;
        this.createdAt = LocalDateTime.now();
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public com.jdc.Prediccion.entity.User getUser() {
        return user;
    }

    public void setUser(com.jdc.Prediccion.entity.User user) {
        this.user = user;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getGameName() {
        return gameName;
    }

    public void setGameName(String gameName) {
        this.gameName = gameName;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public String getUsername() {
        return user != null ? user.getUsername() : "Anonimo";
    }

    public Double getRating() {
        return rating;
    }

    public void setRating(Double rating) {
        this.rating = rating;
    }
}