package com.jdc.Prediccion;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@SpringBootApplication(scanBasePackages = {
        "com.jdc.Prediccion",
        "controller",
        "service",
        "repository",
        "entity",
        "config"
})
@EntityScan(basePackages = {"com.jdc.Prediccion.entity", "entity"})
@EnableJpaRepositories(basePackages = {"com.jdc.Prediccion.repository", "repository"})
public class PrediccionApplication {

    public static void main(String[] args) {
        SpringApplication.run(PrediccionApplication.class, args);
    }
}