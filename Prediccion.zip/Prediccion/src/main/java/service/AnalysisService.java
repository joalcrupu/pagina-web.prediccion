package com.jdc.Prediccion.service;

import com.jdc.Prediccion.entity.Game;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Service
public class AnalysisService {

    public Map<String, Object> resumen(List<Game> games) {
        Map<String, Object> data = new HashMap<>();

        data.put("total", games.size());

        Set<String> plataformas = games.stream()
                .map(Game::getPlataforma)
                .filter(Objects::nonNull)
                .collect(Collectors.toSet());

        data.put("plataformas", plataformas.size());

        OptionalInt minYear = games.stream()
                .map(Game::getAnio)
                .filter(Objects::nonNull)
                .mapToInt(Integer::intValue)
                .min();

        OptionalInt maxYear = games.stream()
                .map(Game::getAnio)
                .filter(Objects::nonNull)
                .mapToInt(Integer::intValue)
                .max();

        data.put("minYear", minYear.orElse(0));
        data.put("maxYear", maxYear.orElse(0));

        // Ventas totales por región
        double totalNA = games.stream()
                .mapToDouble(g -> g.getVentasNA() != null ? g.getVentasNA() : 0)
                .sum();
        double totalEU = games.stream()
                .mapToDouble(g -> g.getVentasEU() != null ? g.getVentasEU() : 0)
                .sum();
        double totalJP = games.stream()
                .mapToDouble(g -> g.getVentasJP() != null ? g.getVentasJP() : 0)
                .sum();
        double totalOtros = games.stream()
                .mapToDouble(g -> g.getVentasOtros() != null ? g.getVentasOtros() : 0)
                .sum();

        data.put("ventasNA", totalNA);
        data.put("ventasEU", totalEU);
        data.put("ventasJP", totalJP);
        data.put("ventasOtros", totalOtros);
        data.put("ventasGlobal", totalNA + totalEU + totalJP + totalOtros);

        return data;
    }
}