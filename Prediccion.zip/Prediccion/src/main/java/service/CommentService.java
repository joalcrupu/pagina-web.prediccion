package com.jdc.Prediccion.service;

import com.jdc.Prediccion.entity.Comment;
import com.jdc.Prediccion.repository.CommentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class CommentService {

    @Autowired
    private CommentRepository commentRepository;

    public List<Comment> getCommentsByGame(String gameName) {
        if (gameName == null || gameName.isEmpty()) {
            return List.of();
        }
        return commentRepository.findByGameNameOrderByCreatedAtDesc(gameName);
    }
    public Comment getCommentById(Long id) {
        return commentRepository.findById(id).orElse(null);
    }
    public Comment saveComment(Comment comment) {
        if (comment.getCreatedAt() == null) {
            comment.setCreatedAt(java.time.LocalDateTime.now());
        }
        return commentRepository.save(comment);
    }

    public void deleteComment(Long id) {
        commentRepository.deleteById(id);
    }
}