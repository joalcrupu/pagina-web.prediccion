package com.jdc.Prediccion.service;

import com.jdc.Prediccion.entity.Game;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class FileService {

    @Autowired
    private com.jdc.Prediccion.service.PredictionService predictionService;

    public void processFiles(MultipartFile[] files) throws Exception {
        System.out.println("=== INICIO PROCESAMIENTO DE ARCHIVOS ===");
        System.out.println("Archivos recibidos: " + files.length);

        List<Game> allGames = new ArrayList<>();

        for (int i = 0; i < files.length; i++) {
            MultipartFile file = files[i];
            String filename = file.getOriginalFilename();
            System.out.println("Procesando archivo " + (i+1) + ": " + filename);
            System.out.println("Tamanio: " + file.getSize() + " bytes");

            List<Game> games = new ArrayList<>();

            if (filename != null && filename.toLowerCase().endsWith(".csv")) {
                System.out.println("Tipo: CSV");
                games = readCSV(file);
                System.out.println("CSV leido: " + games.size() + " juegos");
            } else if (filename != null && (filename.toLowerCase().endsWith(".xlsx") || filename.toLowerCase().endsWith(".xls"))) {
                System.out.println("Tipo: Excel");
                games = readExcel(file);
                System.out.println("Excel leido: " + games.size() + " juegos");
            } else {
                System.out.println("Archivo ignorado (formato no soportado): " + filename);
            }

            allGames.addAll(games);
        }

        System.out.println("Total de juegos procesados: " + allGames.size());

        if (!allGames.isEmpty()) {
            System.out.println("Cargando juegos en PredictionService...");
            predictionService.loadGames(allGames);
            System.out.println("Carga completada");
        } else {
            System.out.println("ERROR: No se encontraron juegos en los archivos");
        }
        System.out.println("=== FIN PROCESAMIENTO ===");
    }

    private List<Game> readCSV(MultipartFile file) throws Exception {
        List<Game> games = new ArrayList<>();
        int lineCount = 0;
        int validCount = 0;

        try (BufferedReader reader = new BufferedReader(new InputStreamReader(file.getInputStream()))) {
            String line;
            boolean firstLine = true;
            Map<String, Integer> columnMap = new HashMap<>();

            while ((line = reader.readLine()) != null) {
                lineCount++;
                String[] parts = line.split(",");

                if (firstLine) {
                    for (int i = 0; i < parts.length; i++) {
                        String header = parts[i].replace("\"", "").trim().toLowerCase();
                        columnMap.put(header, i);
                    }
                    System.out.println("Columnas CSV encontradas: " + columnMap.keySet());
                    firstLine = false;
                    continue;
                }

                if (parts.length < 5) continue;

                Game game = new Game();

                game.setNombre(getValueByColumn(parts, columnMap, "name", "nombre", "title", "titulo"));
                game.setPlataforma(getValueByColumn(parts, columnMap, "platform", "plataforma"));
                game.setAnio(getIntByColumn(parts, columnMap, "year", "year_of_release", "ano", "anio"));
                game.setGenero(getValueByColumn(parts, columnMap, "genre", "genero"));
                game.setEditorial(getValueByColumn(parts, columnMap, "publisher", "editorial"));
                game.setVentasNA(getDoubleByColumn(parts, columnMap, "na_sales", "ventas na", "na"));
                game.setVentasEU(getDoubleByColumn(parts, columnMap, "eu_sales", "ventas eu", "eu"));
                game.setVentasJP(getDoubleByColumn(parts, columnMap, "jp_sales", "ventas jp", "jp"));
                game.setVentasOtros(getDoubleByColumn(parts, columnMap, "other_sales", "ventas otros", "other", "otros"));
                game.setVentasGlobal(getDoubleByColumn(parts, columnMap, "global_sales", "ventas global", "global"));
                game.setCriticScore(getDoubleByColumn(parts, columnMap, "critic_score", "critic", "criticscore"));
                game.setUserScore(getDoubleByColumn(parts, columnMap, "user_score", "user", "userscore"));
                game.setRating(getValueByColumn(parts, columnMap, "rating"));

                if (game.getNombre() != null && !game.getNombre().isEmpty()) {
                    games.add(game);
                    validCount++;
                }
            }
        }

        System.out.println("Lineas CSV procesadas: " + lineCount + ", Juegos validos: " + validCount);
        return games;
    }

    private List<Game> readExcel(MultipartFile file) throws Exception {
        List<Game> games = new ArrayList<>();
        Workbook workbook = null;
        int rowCount = 0;
        int validCount = 0;

        try {
            String filename = file.getOriginalFilename();
            if (filename != null && filename.toLowerCase().endsWith(".xlsx")) {
                workbook = new XSSFWorkbook(file.getInputStream());
                System.out.println("Leyendo XLSX");
            } else if (filename != null && filename.toLowerCase().endsWith(".xls")) {
                workbook = new HSSFWorkbook(file.getInputStream());
                System.out.println("Leyendo XLS");
            }

            if (workbook == null) {
                System.out.println("ERROR: No se pudo crear el workbook");
                return games;
            }

            Sheet sheet = workbook.getSheetAt(0);
            System.out.println("Hoja: " + sheet.getSheetName());
            System.out.println("Filas totales en hoja: " + (sheet.getLastRowNum() + 1));

            Row headerRow = sheet.getRow(0);

            if (headerRow == null) {
                System.out.println("ERROR: No hay fila de encabezados");
                return games;
            }

            Map<String, Integer> columnMap = new HashMap<>();
            for (int i = 0; i < headerRow.getLastCellNum(); i++) {
                Cell cell = headerRow.getCell(i);
                if (cell != null) {
                    String header = getCellValueAsString(cell).toLowerCase().trim();
                    columnMap.put(header, i);
                }
            }
            System.out.println("Columnas Excel encontradas: " + columnMap.keySet());

            for (int rowIndex = 1; rowIndex <= sheet.getLastRowNum(); rowIndex++) {
                Row row = sheet.getRow(rowIndex);
                if (row == null) continue;
                rowCount++;

                Game game = new Game();

                game.setNombre(getCellValueByColumn(row, columnMap, "name", "nombre", "title", "titulo"));
                game.setPlataforma(getCellValueByColumn(row, columnMap, "platform", "plataforma"));
                game.setAnio(getCellIntByColumn(row, columnMap, "year", "year_of_release", "ano", "anio"));
                game.setGenero(getCellValueByColumn(row, columnMap, "genre", "genero"));
                game.setEditorial(getCellValueByColumn(row, columnMap, "publisher", "editorial"));
                game.setVentasNA(getCellDoubleByColumn(row, columnMap, "na_sales", "ventas na", "na"));
                game.setVentasEU(getCellDoubleByColumn(row, columnMap, "eu_sales", "ventas eu", "eu"));
                game.setVentasJP(getCellDoubleByColumn(row, columnMap, "jp_sales", "ventas jp", "jp"));
                game.setVentasOtros(getCellDoubleByColumn(row, columnMap, "other_sales", "ventas otros", "other", "otros"));
                game.setVentasGlobal(getCellDoubleByColumn(row, columnMap, "global_sales", "ventas global", "global"));
                game.setCriticScore(getCellDoubleByColumn(row, columnMap, "critic_score", "critic", "criticscore"));
                game.setUserScore(getCellDoubleByColumn(row, columnMap, "user_score", "user", "userscore"));
                game.setRating(getCellValueByColumn(row, columnMap, "rating"));

                if (game.getNombre() != null && !game.getNombre().isEmpty()) {
                    games.add(game);
                    validCount++;
                }
            }

            workbook.close();
            System.out.println("Filas Excel procesadas: " + rowCount + ", Juegos validos: " + validCount);

        } catch (Exception e) {
            System.err.println("ERROR leyendo Excel: " + e.getMessage());
            e.printStackTrace();
            if (workbook != null) workbook.close();
            throw e;
        }

        return games;
    }

    // Metodos auxiliares para CSV
    private String getValueByColumn(String[] parts, Map<String, Integer> columnMap, String... possibleNames) {
        for (String name : possibleNames) {
            if (columnMap.containsKey(name)) {
                int index = columnMap.get(name);
                if (index < parts.length) {
                    return cleanValue(parts[index]);
                }
            }
        }
        return "";
    }

    private Integer getIntByColumn(String[] parts, Map<String, Integer> columnMap, String... possibleNames) {
        String value = getValueByColumn(parts, columnMap, possibleNames);
        return parseIntSafe(value);
    }

    private Double getDoubleByColumn(String[] parts, Map<String, Integer> columnMap, String... possibleNames) {
        String value = getValueByColumn(parts, columnMap, possibleNames);
        return parseDoubleSafe(value);
    }

    // Metodos auxiliares para Excel
    private String getCellValueByColumn(Row row, Map<String, Integer> columnMap, String... possibleNames) {
        for (String name : possibleNames) {
            if (columnMap.containsKey(name)) {
                int index = columnMap.get(name);
                Cell cell = row.getCell(index);
                return getCellValueAsString(cell);
            }
        }
        return "";
    }

    private Integer getCellIntByColumn(Row row, Map<String, Integer> columnMap, String... possibleNames) {
        String value = getCellValueByColumn(row, columnMap, possibleNames);
        return parseIntSafe(value);
    }

    private Double getCellDoubleByColumn(Row row, Map<String, Integer> columnMap, String... possibleNames) {
        String value = getCellValueByColumn(row, columnMap, possibleNames);
        return parseDoubleSafe(value);
    }

    private String getCellValueAsString(Cell cell) {
        if (cell == null) return "";

        switch (cell.getCellType()) {
            case STRING:
                return cell.getStringCellValue().trim();
            case NUMERIC:
                if (DateUtil.isCellDateFormatted(cell)) {
                    return cell.getDateCellValue().toString();
                } else {
                    double value = cell.getNumericCellValue();
                    if (value == (long) value) {
                        return String.valueOf((long) value);
                    } else {
                        return String.valueOf(value);
                    }
                }
            case BOOLEAN:
                return String.valueOf(cell.getBooleanCellValue());
            case FORMULA:
                try {
                    return getCellValueAsString(cell);
                } catch (Exception e) {
                    return "";
                }
            default:
                return "";
        }
    }

    private String cleanValue(String value) {
        if (value == null) return "";
        return value.replace("\"", "").trim();
    }

    private Integer parseIntSafe(String value) {
        if (value == null || value.isEmpty()) return null;
        try {
            return (int) Double.parseDouble(value);
        } catch (Exception e) {
            return null;
        }
    }

    private Double parseDoubleSafe(String value) {
        if (value == null || value.isEmpty()) return 0.0;
        try {
            return Double.parseDouble(value);
        } catch (Exception e) {
            return 0.0;
        }
    }
}