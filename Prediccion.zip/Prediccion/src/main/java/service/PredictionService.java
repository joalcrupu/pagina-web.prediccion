package com.jdc.Prediccion.service;

import com.jdc.Prediccion.entity.Game;
import org.springframework.stereotype.Service;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class PredictionService {

    private List<Game> games = new ArrayList<>();

    public void loadGames(List<Game> loadedGames) {
        this.games = new ArrayList<>(loadedGames);
        System.out.println("========================================");
        System.out.println(" PredictionService: " + this.games.size() + " juegos cargados");
        if (!this.games.isEmpty()) {
            System.out.println(" Primer juego cargado: " + this.games.get(0).getNombre());
            System.out.println(" Editorial: " + this.games.get(0).getEditorial());
        }
        System.out.println("========================================");
    }

    public Map<String, Object> buscarJuego(String nombre) {
        Map<String, Object> resultado = new HashMap<>();

        System.out.println("========================================");
        System.out.println(" BUSCANDO: " + nombre);
        System.out.println(" Juegos en memoria: " + games.size());

        if (games.isEmpty()) {
            System.out.println(" No hay juegos en memoria!");
            resultado.put("encontrado", false);
            resultado.put("mensaje", "No hay datos cargados. Sube archivos primero.");
            return resultado;
        }

        // Mostrar primeros 5 juegos para debug
        System.out.println(" Primeros juegos disponibles:");
        for (int i = 0; i < Math.min(5, games.size()); i++) {
            Game g = games.get(i);
            System.out.println("   " + (i+1) + ". " + (g.getNombre() != null ? g.getNombre() : "null"));
        }

        String busqueda = nombre.toLowerCase().trim();
        List<Game> encontrados = games.stream()
                .filter(g -> g.getNombre() != null &&
                        g.getNombre().toLowerCase().contains(busqueda))
                .collect(Collectors.toList());

        System.out.println(" Encontrados: " + encontrados.size() + " juegos");

        if (encontrados.isEmpty()) {
            System.out.println(" No se encontraron juegos con: " + nombre);
            resultado.put("encontrado", false);
            resultado.put("mensaje", "Juego no encontrado: " + nombre);
            return resultado;
        }

        Game primerJuego = encontrados.get(0);
        System.out.println(" Primer juego encontrado: " + primerJuego.getNombre());
        System.out.println("========================================");

        resultado.put("encontrado", true);
        resultado.put("total_encontrados", encontrados.size());
        resultado.put("editorial", primerJuego.getEditorial() != null ? primerJuego.getEditorial() : "Desconocida");
        resultado.put("anio", primerJuego.getAnio() != null ? primerJuego.getAnio() : 0);
        resultado.put("genero", primerJuego.getGenero() != null ? primerJuego.getGenero() : "Desconocido");

        Map<String, Double> ventasPromedio = new HashMap<>();
        ventasPromedio.put("NA", encontrados.stream()
                .mapToDouble(g -> g.getVentasNA() != null ? g.getVentasNA() : 0)
                .average().orElse(0));
        ventasPromedio.put("EU", encontrados.stream()
                .mapToDouble(g -> g.getVentasEU() != null ? g.getVentasEU() : 0)
                .average().orElse(0));
        ventasPromedio.put("JP", encontrados.stream()
                .mapToDouble(g -> g.getVentasJP() != null ? g.getVentasJP() : 0)
                .average().orElse(0));
        ventasPromedio.put("Otros", encontrados.stream()
                .mapToDouble(g -> g.getVentasOtros() != null ? g.getVentasOtros() : 0)
                .average().orElse(0));
        resultado.put("ventas_promedio", ventasPromedio);

        Map<String, Double> calidadPromedio = new HashMap<>();
        calidadPromedio.put("Critic_Score", encontrados.stream()
                .mapToDouble(g -> g.getCriticScore() != null ? g.getCriticScore() : 0)
                .average().orElse(0));
        calidadPromedio.put("User_Score", encontrados.stream()
                .mapToDouble(g -> g.getUserScore() != null ? g.getUserScore() : 0)
                .average().orElse(0));
        resultado.put("calidad_promedio", calidadPromedio);

        return resultado;
    }

    public Map<String, Object> predecirJuego(String nombre, String genero, String plataforma,
                                             String editorial, Integer anio, String rating) {
        Map<String, Object> resultado = new HashMap<>();

        String saga = detectarSaga(nombre);
        String nivelSaga = calcularNivelSaga(saga);

        double prediccionBase = 1.5;

        double factorSaga = calcularFactorSaga(saga);
        double factorGenero = calcularFactorGenero(genero);
        double factorPlataforma = calcularFactorPlataforma(plataforma);
        double factorEditorial = calcularFactorEditorial(editorial);
        double factorRating = calcularFactorRating(rating);
        double factorAnio = calcularFactorAnio(anio);

        double factorTotal = factorSaga * factorGenero * factorPlataforma * factorEditorial * factorRating * factorAnio;
        double ventaEstimada = prediccionBase * factorTotal;

        Map<String, Double> ventasEstimadas = new HashMap<>();
        ventasEstimadas.put("NA", Math.round(ventaEstimada * 0.9 * 100.0) / 100.0);
        ventasEstimadas.put("EU", Math.round(ventaEstimada * 1.2 * 100.0) / 100.0);
        ventasEstimadas.put("JP", Math.round(ventaEstimada * 0.7 * 100.0) / 100.0);
        ventasEstimadas.put("Otros", Math.round(ventaEstimada * 0.6 * 100.0) / 100.0);
        ventasEstimadas.put("Total", Math.round(ventaEstimada * 3.4 * 100.0) / 100.0);

        resultado.put("nombre", nombre);
        resultado.put("saga", saga);
        resultado.put("nivel_saga", nivelSaga);
        resultado.put("ventas_estimadas", ventasEstimadas);

        Map<String, String> analisisRegion = new HashMap<>();
        for (Map.Entry<String, Double> entry : ventasEstimadas.entrySet()) {
            if (!entry.getKey().equals("Total")) {
                if (entry.getValue() > 1.5) analisisRegion.put(entry.getKey(), "fuerte");
                else if (entry.getValue() > 0.6) analisisRegion.put(entry.getKey(), "aceptable");
                else analisisRegion.put(entry.getKey(), "debil");
            }
        }
        resultado.put("analisis_region", analisisRegion);

        int probabilidad = (int) Math.min(95, Math.max(10, factorTotal * 50));
        resultado.put("probabilidad_exito", probabilidad);

        String recomendacion;
        if (probabilidad >= 70) recomendacion = "Muy recomendable";
        else if (probabilidad >= 50) recomendacion = "Buen candidato";
        else if (probabilidad >= 35) recomendacion = "Aceptable";
        else recomendacion = "Bajo potencial";
        resultado.put("recomendacion", recomendacion);

        return resultado;
    }

    private String detectarSaga(String nombre) {
        if (nombre == null) return "Unknown";
        String lower = nombre.toLowerCase();
        String[] sagas = {"fifa", "call of duty", "pokemon", "mario", "zelda",
                "final fantasy", "grand theft auto", "resident evil", "halo",
                "god of war", "minecraft"};
        for (String saga : sagas) {
            if (lower.contains(saga)) return saga;
        }
        return "Unknown";
    }

    private String calcularNivelSaga(String saga) {
        if (saga.equals("Unknown")) return "desconocida";
        List<Game> sagas = games.stream()
                .filter(g -> g.getNombre() != null && g.getNombre().toLowerCase().contains(saga))
                .collect(Collectors.toList());
        if (sagas.isEmpty()) return "desconocida";
        double ventasPromedio = sagas.stream()
                .mapToDouble(g -> g.getVentasGlobal() != null ? g.getVentasGlobal() : 0)
                .average().orElse(0);
        if (ventasPromedio > 10) return "muy fuerte";
        if (ventasPromedio > 5) return "fuerte";
        if (ventasPromedio > 2) return "media";
        return "debil";
    }

    private double calcularFactorSaga(String saga) {
        List<Game> sagas = games.stream()
                .filter(g -> g.getNombre() != null && g.getNombre().toLowerCase().contains(saga))
                .collect(Collectors.toList());
        if (sagas.isEmpty()) return 0.8;
        double promedio = sagas.stream()
                .mapToDouble(g -> g.getVentasGlobal() != null ? g.getVentasGlobal() : 0)
                .average().orElse(0);
        return Math.min(2.0, Math.max(0.5, promedio / 5.0));
    }

    private double calcularFactorGenero(String genero) {
        if (genero == null) return 1.0;
        Map<String, Double> factores = new HashMap<>();
        factores.put("sports", 1.3);
        factores.put("action", 1.2);
        factores.put("rpg", 1.1);
        factores.put("adventure", 1.0);
        factores.put("strategy", 0.9);
        factores.put("puzzle", 0.8);
        factores.put("shooter", 1.25);
        factores.put("racing", 1.1);
        factores.put("fighting", 1.05);
        factores.put("simulation", 0.95);
        return factores.getOrDefault(genero.toLowerCase(), 1.0);
    }

    private double calcularFactorPlataforma(String plataforma) {
        if (plataforma == null) return 1.0;
        Map<String, Double> factores = new HashMap<>();
        factores.put("ps5", 1.4);
        factores.put("ps4", 1.3);
        factores.put("ps3", 1.1);
        factores.put("xbox series", 1.2);
        factores.put("xbox one", 1.1);
        factores.put("xbox 360", 1.0);
        factores.put("switch", 1.3);
        factores.put("wii", 1.2);
        factores.put("wii u", 0.8);
        factores.put("pc", 1.1);
        factores.put("mobile", 0.7);
        return factores.getOrDefault(plataforma.toLowerCase(), 1.0);
    }

    private double calcularFactorEditorial(String editorial) {
        if (editorial == null) return 1.0;
        Map<String, Double> factores = new HashMap<>();
        factores.put("ea", 1.3);
        factores.put("nintendo", 1.4);
        factores.put("sony", 1.2);
        factores.put("microsoft", 1.1);
        factores.put("ubisoft", 1.1);
        factores.put("activision", 1.2);
        factores.put("rockstar", 1.5);
        factores.put("capcom", 1.15);
        factores.put("square enix", 1.1);
        factores.put("sega", 0.9);
        return factores.getOrDefault(editorial.toLowerCase(), 1.0);
    }

    private double calcularFactorRating(String rating) {
        if (rating == null) return 1.0;
        Map<String, Double> factores = new HashMap<>();
        factores.put("E", 1.2);
        factores.put("E10+", 1.1);
        factores.put("T", 1.0);
        factores.put("M", 0.9);
        factores.put("AO", 0.7);
        factores.put("RP", 0.8);
        return factores.getOrDefault(rating.toUpperCase(), 1.0);
    }

    private double calcularFactorAnio(Integer anio) {
        if (anio == null) return 1.0;
        int anioActual = java.time.Year.now().getValue();
        int antiguedad = anioActual - anio;
        if (antiguedad <= 0) return 1.3;
        if (antiguedad == 1) return 1.2;
        if (antiguedad == 2) return 1.1;
        if (antiguedad <= 5) return 1.0;
        if (antiguedad <= 10) return 0.8;
        return 0.6;
    }
}